// App.js
import React from 'react';
import './App.css';

import FilterTableComponent from './components/filter.table';

function App() {

  return (
    <div >

     
     
      <FilterTableComponent />
      
    </div>
  );
}

export default App;
